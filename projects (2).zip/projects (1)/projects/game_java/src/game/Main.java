package game;

import java.util.*;
import static game.InOutUtils.readStringsFromInputStream;
import static game.ProcessUtils.UTF_8;

/**
 * Main samplegame class.
 */
public class Main {

    public static void main(String[] args) {
        List<String> input = readStringsFromInputStream(System.in, UTF_8);
        if(!input.isEmpty()){
            Round round = new Round(input);
            printMovingGroups(makeMove(round));
        }
        System.exit(0);
    }

    private static List<MovingGroup> makeMove(Round round) {
        List<MovingGroup> movingGroups = new ArrayList<>();
        MovingGroup group1= new MovingGroup();
        MovingGroup group2= new MovingGroup();
        MovingGroup group3= new MovingGroup();
        MovingGroup group4= new MovingGroup();
        MovingGroup group5= new MovingGroup();
        MovingGroup group6= new MovingGroup();
        MovingGroup group7= new MovingGroup();
        MovingGroup group8= new MovingGroup();
        MovingGroup group9= new MovingGroup();
        movingGroups.add(group1);
        movingGroups.add(group2);
        movingGroups.add(group3);
        movingGroups.add(group4);
        movingGroups.add(group5);
        movingGroups.add(group6);
        movingGroups.add(group7);
        movingGroups.add(group8);
        movingGroups.add(group9);
        Planet home = round.getOwnPlanets().get(0);
        int homePlanetId =home.getId();
        group1.setFrom(homePlanetId);
        group2.setFrom(homePlanetId);
        group3.setFrom(homePlanetId);
        group4.setFrom(homePlanetId);
        group5.setFrom(homePlanetId);
        group6.setFrom(homePlanetId);
        group7.setFrom(homePlanetId);
        group8.setFrom(homePlanetId);
        group9.setFrom(homePlanetId);
        if (round.getCurrentStep()==0) {
            if (homePlanetId == 0) {
                group1.setTo(1);
                group1.setCount(10);
                group2.setTo(4);
                group2.setCount(32);
                group3.setTo(5);
                group3.setCount(32);
                group4.setTo(3);
                group4.setCount(10);
                group5.setTo(2);
                group5.setCount(9);
            } else {
                group1.setTo(8);
                group1.setCount(10);
                group2.setTo(4);
                group2.setCount(32);
                group3.setTo(5);
                group3.setCount(32);
                group4.setTo(6);
                group4.setCount(10);
                group5.setTo(7);
                group5.setCount(9);
            }}
            if (round.getCurrentStep() == 6){
                if (homePlanetId == 0) {
                    group1.setFrom(1);
                    group1.setTo(2);
                    group1.setCount(5);
                    group6.setTo(1);
                    group6.setCount(5);
                    group7.setTo(5);
                    group7.setCount(5);
                    group8.setTo(3);
                    group8.setCount(5);

                } else {
                    group1.setFrom(8);
                    group1.setTo(7);
                    group1.setCount(5);
                    group6.setTo(8);
                    group6.setCount(5);
                    group7.setTo(6);
                    group7.setCount(5);
                    group8.setTo(5);
                    group8.setCount(5);
                }
            }
            if (round.getCurrentStep() == 11) {
                if (homePlanetId == 0) {
                    group4.setFrom(3);
                    group4.setTo(7);
                    group4.setCount(5);
                    group5.setFrom(2);
                    group5.setTo(7);
                    group5.setCount(9);
                } else {
                    group4.setFrom(6);
                    group4.setTo(2);
                    group4.setCount(5);
                    group5.setFrom(7);
                    group5.setTo(2);
                    group5.setCount(5);
                }
            }

        return movingGroups;
    }

    private static void printMovingGroups(List<MovingGroup> moves) {
        System.out.println(moves.size());
        moves.forEach(move -> System.out.println(move.getFrom() + " " + move.getTo() + " " + move.getCount()));
    }

}
