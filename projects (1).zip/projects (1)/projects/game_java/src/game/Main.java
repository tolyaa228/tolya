package game;

import java.util.*;
import static game.InOutUtils.readStringsFromInputStream;
import static game.ProcessUtils.UTF_8;

/**
 * Main samplegame class.
 */
public class Main {

    public static void main(String[] args) {
        List<String> input = readStringsFromInputStream(System.in, UTF_8);
        if(!input.isEmpty()){
            Round round = new Round(input);
            printMovingGroups(makeMove(round));
        }
        System.exit(0);
    }

    private static List<MovingGroup> makeMove(Round round) {
        List<MovingGroup> movingGroups = new ArrayList<>();
        MovingGroup group1= new MovingGroup();
        MovingGroup group2= new MovingGroup();
        MovingGroup group3= new MovingGroup();
        MovingGroup group4= new MovingGroup();
        MovingGroup group5= new MovingGroup();
        movingGroups.add(group1);
        movingGroups.add(group2);
        movingGroups.add(group3);
        movingGroups.add(group4);
        movingGroups.add(group5);
        Planet home = round.getOwnPlanets().get(0);
        int homePlanetId =home.getId();
        group1.setFrom(homePlanetId);
        group2.setFrom(homePlanetId);
        group3.setFrom(homePlanetId);
        if (round.getCurrentStep()==0){
          if (homePlanetId==0){
        group1.setTo(1);
        group1.setCount(20);
        group2.setTo(4);
        group2.setCount(31);
        group3.setTo(5);
        group3.setCount(31);}
         else{
              group1.setTo(8);
              group1.setCount(20);
              group2.setTo(4);
              group2.setCount(20);
              group3.setTo(5);
              group3.setCount(20);
         }
        }
        return movingGroups;
    }

    private static void printMovingGroups(List<MovingGroup> moves) {
        System.out.println(moves.size());
        moves.forEach(move -> System.out.println(move.getFrom() + " " + move.getTo() + " " + move.getCount()));
    }

}
