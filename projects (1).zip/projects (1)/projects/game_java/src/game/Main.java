package game;

import java.util.*;
import static game.InOutUtils.readStringsFromInputStream;
import static game.ProcessUtils.UTF_8;

/**
 * Main samplegame class.
 */
public class Main {

    public static void main(String[] args) {
        List<String> input = readStringsFromInputStream(System.in, UTF_8);
        if(!input.isEmpty()){
            Round round = new Round(input);
            printMovingGroups(makeMove(round));
        }
        System.exit(0);
    }

    private static List<MovingGroup> makeMove(Round round) {
        List<MovingGroup> movingGroups = new ArrayList<>();
        MovingGroup group1= new MovingGroup();
        MovingGroup group2= new MovingGroup();
        MovingGroup group3= new MovingGroup();
        MovingGroup group4= new MovingGroup();
        MovingGroup group5= new MovingGroup();
        MovingGroup group6= new MovingGroup();
        MovingGroup group7= new MovingGroup();
        MovingGroup group8= new MovingGroup();
        MovingGroup group9= new MovingGroup();
        MovingGroup group10= new MovingGroup();
        MovingGroup group11= new MovingGroup();
        MovingGroup group12= new MovingGroup();
        MovingGroup group13= new MovingGroup();
        movingGroups.add(group1);
        movingGroups.add(group2);
        movingGroups.add(group3);
        movingGroups.add(group4);
        movingGroups.add(group5);
        movingGroups.add(group6);
        movingGroups.add(group7);
        movingGroups.add(group8);
        movingGroups.add(group9);
        movingGroups.add(group10);
        movingGroups.add(group11);
        movingGroups.add(group12);
        movingGroups.add(group13);
        Planet home = round.getOwnPlanets().get(0);
        int homePlanetId =home.getId();
        group1.setFrom(homePlanetId);
        group2.setFrom(homePlanetId);
        group3.setFrom(homePlanetId);
        group4.setFrom(homePlanetId);
        group5.setFrom(homePlanetId);
        if (round.getCurrentStep()==0){
          if (homePlanetId==0){
        group1.setTo(1);
        group1.setCount(8);
        group2.setTo(2);
        group2.setCount(9);
        group3.setTo(3);
        group3.setCount(8);
        group4.setTo(4);
        group4.setCount(36);
        group5.setTo(5);
        group5.setCount(36);}
         else{
              group1.setTo(8);
              group1.setCount(8);
              group2.setTo(7);
              group2.setCount(9);
              group3.setTo(6);
              group3.setCount(8);
              group4.setTo(5);
              group4.setCount(36);
              group5.setTo(4);
              group5.setCount(36);
         }
        }
        if(round.getCurrentStep() % 2 ==0)
        if (homePlanetId==0) {
            group6.setFrom(1);
            group6.setTo(2);
            group6.setCount(5);
            group7.setFrom(1);
            group7.setTo(3);
            group7.setCount(5);
            group8.setFrom(3);
            group8.setTo(4);
            group8.setCount(10);
            group9.setFrom(2);
            group9.setTo(5);
            group9.setCount(5);
            group10.setFrom(0);
            group10.setTo(1);
            group10.setCount(4);
            group11.setFrom(2);
            group11.setTo(3);
            group11.setCount(5);
        }else{
            group6.setFrom(8);
            group6.setTo(7);
            group6.setCount(5);
            group7.setFrom(8);
            group7.setTo(6);
            group7.setCount(5);
            group8.setFrom(6);
            group8.setTo(5);
            group8.setCount(10);
            group9.setFrom(7);
            group9.setTo(4);
            group9.setCount(3);
            group10.setFrom(9);
            group10.setTo(8);
            group10.setCount(4);
            group11.setFrom(7);
            group11.setTo(6);
            group11.setCount(5);
        }
        return movingGroups;
    }

    private static void printMovingGroups(List<MovingGroup> moves) {
        System.out.println(moves.size());
        moves.forEach(move -> System.out.println(move.getFrom() + " " + move.getTo() + " " + move.getCount()));
    }

}
